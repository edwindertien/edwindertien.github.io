# Grading matrix - Sensors A6

Score per criterion (calibration record). The first column is the reference example (Edwin, strict reading). Add one column per graded pair/student.

| Criterion | max | Reference example |
| --- | --- | --- |
| intro_type | 1 | 1 |
| intro_principle | 1 | 1 |
| intro_goal | 1 | 1 |
| an_measurand | 1 | 1 |
| an_principle | 1 | 1 |
| an_reference | 1 | 1 |
| an_equations | 2 | 1 |
| an_conditioning | 2 | 1 |
| me_setup | 1 | 0 |
| me_code | 2 | 2 |
| me_reference | 1 | 1 |
| me_samples | 1 | 1 |
| me_procedure | 1 | 1 |
| re_time | 1 | 1 |
| re_calibration | 1 | 1 |
| re_error | 1 | 1 |
| re_nonlinear | 1 | 0 |
| re_graphing | 1 | 1 |
| co_accuracy | 1 | 0 |
| co_resolution | 1 | 1 |
| co_precision | 1 | 0 |
| co_range | 1 | 1 |
| co_nonlin | 1 | 0 |
| co_improve | 1 | 1 |
| fo_template | 2 | 2 |
| fo_references | 1 | 1 |
| **Total** | 30 | **23** (grade 7.9) |

Borderline calls in the reference example (each worth about 0.3 grade point): an_reference (principle not explained, alignment not discussed), me_reference (alignment of the angle scales), me_procedure (very brief), me_setup (no conditions: 0 under the A3 rule), re_nonlinear (bumps shown in Fig. 7 but no Lissajous or close-up).
If you want the reference anchored at a 7 (20/30) like the A3 worked example: tighten an_reference, me_reference and me_procedure to 0.