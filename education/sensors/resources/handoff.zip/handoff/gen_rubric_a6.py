#!/usr/bin/env python3
"""Generate rubric-sensors-hall.yaml (Assignment 6, Hall-effect rotation sensor) from a compact definition.

Rules for strings (the YAML is also embedded in a JS template literal in the HTML tool):
no double quotes, backticks, backslashes or the sequence dollar-brace.
usage: python3 gen_rubric_a6.py OUT.yaml
"""
import sys

S = []   # sections: (id, title, banner, [criteria])


def C(id, label, pts, desc, neg, pos):
    return dict(id=id, label=label, pts=pts, desc=desc, neg=neg, pos=pos)


# ───────────────────────────── 1. INTRODUCTION · 3 pt ─────────────────────────────
S.append(("intro", "introduction", "1. INTRODUCTION  ·  3 pt  (1+1+1)", [
    C("intro_type", "introduction - sensor type", 1,
      "Is the correct sensor type mentioned? (Two linear, ratiometric Hall-effect sensors (A1302 or similar) read out with a wheel of alternating magnets, and a potentiometer as reference.)",
      ["sensor type missing or vague (only 'an angle sensor')",
       "only the Hall sensors, or only the potentiometer, named",
       "wrong sensor type (e.g. optical encoder, or a Hall switch / latch instead of a linear Hall sensor)"],
      ["linear (ratiometric) Hall-effect sensor named, together with the magnet wheel",
       "potentiometer named as the reference"]),
    C("intro_principle", "introduction - physical principle", 1,
      "Is the physical measurement principle mentioned?",
      ["no physical principle mentioned",
       "principle given for only one of the two sensors (Hall or potentiometer)",
       "describes the electronics or the process instead of the physics"],
      ["Hall effect: a magnetic field gives an output voltage proportional to the flux density",
       "two sensors with a 90 degree phase difference give a sine / cosine pair from which the angle follows",
       "potentiometer: wiper voltage proportional to the angle"]),
    C("intro_goal", "introduction - measurement goal", 1,
      "Is the goal clearly stated, without irrelevant (process-related) information?",
      ["goal missing or unclear",
       "goal buried in a description of what was done or which hardware was handed out",
       "goal is only 'to do the assignment'"],
      ["goal stated in one or two sentences (implement and characterise the Hall-effect angle sensor with the potentiometer as reference)",
       "properties to be determined are named (angular range, resolution, precision, accuracy)"]),
]))

# ───────────────────────────── 2. ANALYSIS · 7 pt ─────────────────────────────
S.append(("analysis", "analysis", "2. ANALYSIS  ·  7 pt  (1+1+1+2+2)", [
    C("an_measurand", "analysis - measurand", 1,
      "It is clearly described what is measured: which physical quantity and in which units. Reference: the rotation angle of the wheel (mechanical angle, in degrees) over the total range (270 degrees for the 9-magnet wheel). One magnet transition is 360 electrical degrees, which is two magnet pitches (67.5 mechanical degrees), so electrical and mechanical angle must not be mixed up.",
      ["measurand not named",
       "mechanical and electrical angle mixed up (a transition is 360 electrical degrees, not 360 mechanical degrees)",
       "only raw ADC counts or volts, no angle unit",
       "degrees and radians mixed, or units inconsistent between text and graphs"],
      ["measurand named explicitly (rotation angle of the wheel)",
       "unit stated (degrees) with the relation between electrical and mechanical angle (360 electrical degrees = 2 magnet pitches = 67.5 degrees for 9 magnets over 270 degrees)",
       "same units used throughout text and graphs"]),
    C("an_principle", "analysis - physical principle", 1,
      "The physical principle used for the sensor is described concisely and correctly: Hall effect with magnets of alternating polarity, a linear ratiometric output around half the supply voltage, and why two sensors with a phase offset give a sine / cosine pair. Note: part of this text is pre-filled in the template, so look for the student's own explanation.",
      ["only the pre-filled template text, no own explanation",
       "alternating polarity of the magnets not mentioned, so the period per transition is unexplained",
       "Hall sensor described wrongly (e.g. output proportional to the magnet position, or a switching output instead of a linear one)",
       "phase difference not explained (sensor distance versus magnet distance, see the figure with D_sensor and D_magnet)",
       "not concise (copied datasheet text)"],
      ["output voltage proportional to the field through the sensor, quiescent output at half the supply, ratiometric",
       "magnets alternate N / S, so one transition (360 electrical degrees) spans two magnet pitches",
       "sensor spacing equals one transition plus 90 degrees, which gives the sine / cosine pair",
       "concise and correct"]),
    C("an_reference", "analysis - the reference", 1,
      "The reference used to characterise the sensor is discussed, including its operating principle and its limits. Reference values: rotary potentiometer 10 kOhm, wiper voltage proportional to the angle; effective (electrical) angle about 252 degrees for the full output swing (the mechanical stop of the RK09K family is about 280 degrees); read with the 10-bit ADC, which is 0.25 degrees per count.",
      ["reference mentioned but operating principle not explained (resistive divider with a wiper)",
       "potentiometer specifications missing or wrong (electrical angle, resistance, taper)",
       "no discussion of the limits of the reference (electrical versus mechanical angle, linearity tolerance, ADC resolution)",
       "no discussion of how the potentiometer angle is aligned with the wheel angle (zero offset, angle range)"],
      ["wiper of the 10 kOhm potentiometer as a voltage divider explained",
       "specifications quoted correctly with source (effective electrical angle, linear taper)",
       "reference limitations mentioned (electrical angle smaller than the wheel range, 0.25 degrees per ADC count, linearity)",
       "alignment of the two angle scales discussed"]),
    C("an_equations", "analysis - relevant equations", 2,
      "The equations from physical quantity, to electrical signal (voltage), to value in degrees (software), for both the sensor and the reference. Reference values: about 480 G at the sensor (field calculator, N45 magnet 4 x 1.5 mm) x 1.3 mV/G = about 0.62 V swing around 2.5 V = about 245 ADC counts peak-to-peak (a quarter of the ADC range); x = (A4 - mid) / amplitude, y = (A5 - mid) / amplitude; theta_el = atan2(y, x); unwrapping by adding or subtracting 360 at every jump; theta = summed electrical angle x 270 / 1440 for 9 magnets (4 transitions); reference angle = 252 x ADC / 1023.",
      ["no chain from field to voltage to ADC count to angle",
       "equations only for one of the two sensors",
       "arctan(y / x) used where atan2 is needed (quadrant lost), or the two signals swapped or not offset-corrected",
       "transition counting (unwrapping) not given",
       "scaling from summed electrical angle to mechanical angle missing or inverted (multiply versus divide)",
       "expected voltage swing from sensitivity and field calculator not given",
       "template placeholders left empty ([n], [deg], [mV/gauss])"],
      ["sensitivity and field combined to the expected swing in mV and in ADC counts",
       "angle within one transition from atan2 of the two offset-corrected signals",
       "unwrapping rule and scaling to mechanical degrees correct and consistent with the code",
       "reference angle equation with the datasheet value of the potentiometer",
       "all values with units"]),
    C("an_conditioning", "analysis - conditioning", 2,
      "The circuits used for conditioning the sensor signals are described: supply and output of the Hall sensors, the potentiometer divider, the ADC inputs (A4, A5, A0). The expected use of the ADC range is discussed (the signals only occupy a small part of 0-5 V) and the offset and amplitude correction (centre at 2.5 V, normalisation) is explained. The used components are shown in the schematic.",
      ["schematic missing, or template specimen left in",
       "components or pin numbers (A4, A5, A0) not labelled",
       "only one of the two signal paths shown (Hall sensors or potentiometer)",
       "fraction of the ADC range that is used not estimated",
       "offset (2.5 V centre) and amplitude not discussed, a fixed value of 512 assumed without comment",
       "figure not referenced in the text"],
      ["schematic shows both Hall sensors on A4 and A5 and the potentiometer on A0",
       "component values and designators match the text",
       "expected swing compared with the ADC range (about 245 of 1023 counts)",
       "ratiometric output read by a ratiometric ADC (supply variations cancel), and tolerance of quiescent output and sensitivity mentioned",
       "figure referenced where discussed"]),
]))

# ───────────────────────────── 3. METHOD & SETUP · 6 pt ─────────────────────────────
S.append(("method", "method & setup", "3. METHOD & SETUP  ·  6 pt  (1+2+1+1+1)", [
    C("me_setup", "method - setup", 1,
      "The setup is described: physical aspects (the wheel with its number of magnets and their spacing, the distance between magnets and sensors, how the wheel is turned, where the potentiometer sits), location of the used components on the shield, and the setting of the experiment (room, temperature, at a desk).",
      ["no physical description (wheel, magnets, air gap, how it is rotated)",
       "shield drawing missing, generic, or used parts not marked",
       "number of magnets, spacing or air gap not stated",
       "experiment conditions (room, temperature, desk) not mentioned",
       "no photo or sketch of the wheel and the magnet placement"],
      ["annotated shield drawing marking the Hall sensors and the potentiometer",
       "wheel drawing or photo with the number of magnets, spacing (33.75 degrees for 9 magnets over 270 degrees) and air gap",
       "conditions stated (room, approximate temperature, table)",
       "how the wheel was turned (by hand, slowly) described"]),
    C("me_code", "method - code", 2,
      "The code used for the experiment is described and given. Concise, cleaned-up and minimal; copy-pasting from the reader is not the way to go. The code outputs the computed angle and the reference angle.",
      ["code copied from the reader or wiki without cleaning",
       "long listing with unused parts or no comments",
       "constants or formulas in the code do not match the text (offset, scaling 270/1440, atan2 argument order)",
       "code for the angle or for the reference conversion missing",
       "no unwrapping (transition counting) in the code",
       "listing formatted poorly (large white space, unreadable)"],
      ["short listing covering both conversions (Hall angle and potentiometer angle per line)",
       "unwrapping and scaling visible and matching the text",
       "constants (centre, amplitude, scale) traceable to the data",
       "code explained in the text (what it does, sample rate)"]),
    C("me_reference", "method - reference", 1,
      "The reference signal, reference measurement or calibration source is described.",
      ["no description of how the potentiometer angle is obtained (range, offset)",
       "zero position of wheel and potentiometer not aligned, or the alignment not described",
       "potentiometer range taken from the datasheet without checking it against the wheel range",
       "'calibrated' claimed without any data"],
      ["potentiometer conversion with the effective angle from the datasheet",
       "alignment (offset and scale) of the reference and the sensor angle determined from the data",
       "accuracy or resolution of the reference mentioned (0.25 degrees per count, linearity)"]),
    C("me_samples", "method - samples", 1,
      "The number of samples, measurements or series taken is stated.",
      ["number of swings or samples not stated",
       "only a single swing",
       "sampling interval / rate not mentioned",
       "no static points or sorted data for the precision"],
      ["number of swings and direction (up and down) stated",
       "sample rate stated",
       "enough swings to see repeatability (3 or more)",
       "number of samples behind the precision value stated"]),
    C("me_procedure", "method - procedure", 1,
      "The steps taken, and in which order, are described.",
      ["steps not in order or not reproducible",
       "rotation speed or direction not described",
       "unclear how the starting position and the transition count were initialised",
       "end stops of the potentiometer or the wheel range not mentioned"],
      ["ordered steps from raw signals to calibrated angle",
       "slow, repeated swings over the full range, in both directions",
       "starting position and initial segment defined",
       "precision measured at fixed angles (holds) or by sorting the data"]),
]))

# ───────────────────────────── 4. RESULTS · 5 pt ─────────────────────────────
S.append(("results", "results", "4. RESULTS  ·  5 pt  (1+1+1+1+1)", [
    C("re_time", "results - time series", 1,
      "A clear graph showing the experimental procedure: the raw values of the two Hall sensors and the potentiometer in time over a number of swings, corresponding to the outlined procedure. The raw values show how much of the ADC range is used.",
      ["no time series of the raw values shown",
       "swings not recognisable",
       "time axis in sample number only, or not in seconds",
       "raw counts and degrees on one unlabelled axis",
       "the two Hall signals not distinguishable"],
      ["raw A4, A5 and potentiometer in one graph, clear swings",
       "time axis in seconds",
       "used part of the ADC range visible (about 400-600 counts)",
       "corresponds to the described procedure"]),
    C("re_calibration", "results - calibration graph", 1,
      "A clear graph showing sensor data and reference data. A time series can be added, but the important one is the x-y graph of the calculated angle versus the potentiometer angle.",
      ["no x-y plot, only time series",
       "axes swapped (reference belongs on x)",
       "no ideal line (y = x) to judge the deviation",
       "unlabelled axes or units",
       "offset between the two angle scales not corrected"],
      ["x-y plot: calculated angle versus reference angle, in degrees",
       "ideal line drawn",
       "several swings visible",
       "calculated angle and reference also shown in one time series"]),
    C("re_error", "results - error plot", 1,
      "A clear graph showing the error (difference between reference and measured value). The reference angle range on the x-axis is better than the time series.",
      ["no error plot",
       "error plotted against time instead of against the reference angle",
       "error definition or sign not stated",
       "edges of the range (where the reference saturates) not commented"],
      ["error versus reference angle, in degrees",
       "valid range indicated, or the edges explained",
       "sign convention stated",
       "periodic pattern with the magnet pitch visible or discussed"]),
    C("re_nonlinear", "results - non-ideal details", 1,
      "Graphs showing relevant details of non-ideal behaviour: the x-y (Lissajous) plot of the two Hall signals (a circle when offsets, amplitudes and the 90 degree phase are right), the error within one magnet transition, or a close-up showing the resolution steps. (Hysteresis is not asked in this assignment.)",
      ["non-ideal behaviour claimed (bumps, edge errors) but not shown",
       "no x-y plot of the two Hall signals",
       "no close-up of one or two transitions",
       "bumps visible in the angle but not analysed"],
      ["Lissajous plot of A4 against A5 showing offset, ellipse or distortion",
       "close-up of a few transitions with the error pattern",
       "close-up of the angle steps at slow rotation (resolution)"]),
    C("re_graphing", "results - graphing quality", 1,
      "The graphs show a relevant number of samples, have good scaling, and relevant (SI) units on the axes (degrees, seconds, counts or volts).",
      ["axis titles or units missing (default chart titles)",
       "raw counts and angles mixed on one axis",
       "poor scaling, or too few samples",
       "units not consistent with the text (degrees versus radians, electrical versus mechanical)"],
      ["all axes labelled with units",
       "sensible scaling and enough samples",
       "units consistent with the text"]),
]))

# ───────────────────────────── 5. CONCLUSION · 6 pt ─────────────────────────────
S.append(("conclusion", "conclusion", "5. CONCLUSION  ·  6 pt  (1+1+1+1+1+1)", [
    C("co_accuracy", "conclusion - accuracy", 1,
      "A meaningful and quantified notion of accuracy, linked to the angular range of the sensor. The accuracy of the reference is discussed too. The mean and standard deviation of the error tell only part of the story: look for the worst-case error, and the error in the middle of the range versus the edges.",
      ["accuracy given only as the mean error (close to zero by symmetry)",
       "no link to the range (no percentage of the 270 degrees)",
       "accuracy of the reference (linearity, ADC step, electrical angle) not discussed",
       "edge errors (outside the valid reference range) included without comment"],
      ["worst-case or RMS error in degrees and as percentage of the range",
       "accuracy of the reference discussed (potentiometer linearity, 0.25 degrees per count)",
       "range over which the number holds is stated",
       "error without the edge region also given"]),
    C("co_resolution", "conclusion - resolution", 1,
      "A meaningful, quantified notion of resolution, for both the reference and the sensor signal. Pay attention to the voltage range that the Hall sensors actually use. Reference: potentiometer 252 / 1023 = 0.25 degrees per count; Hall signals: a swing of about 245 counts (a quarter of the ADC range); a single-signal estimate gives 270 / 960 = 0.28 degrees; with two signals and atan2 the electrical resolution is about 1 / A radians (A = amplitude in counts, about 120), which is about 0.1 mechanical degrees.",
      ["resolution only as ADC bits or counts, not translated to degrees",
       "voltage range actually used (about 0.6 V around 2.5 V) not taken into account: 10 bit assumed over the full range",
       "no value for the Hall angle, or none for the reference",
       "resolution of the reference not compared with that of the sensor",
       "single-signal estimate used without discussing the effect of combining two signals"],
      ["reference resolution in degrees per count (about 0.25 degrees)",
       "used ADC range translated into degrees per count for the Hall signals",
       "effective resolution with atan2 derived or measured from the data (smallest step at slow rotation)",
       "limit of the reference as measurement instrument mentioned"]),
    C("co_precision", "conclusion - precision", 1,
      "Precision can be calculated from multiple measurements of the same thing (the same angle), giving a (standard) deviation. The standard deviation of the error is related, but repeated readings at fixed angles, or the sorted data at a number of angles, is better.",
      ["precision confused with accuracy (standard deviation of the error over the whole range called precision)",
       "no repeated measurement at the same angle",
       "standard deviation of the error given without noting its limitation (it contains systematic errors per transition)"],
      ["standard deviation of repeated readings at fixed angles (static holds) or of sorted data per angle bin",
       "noise in ADC counts translated into degrees",
       "number of samples behind the value stated"]),
    C("co_range", "conclusion - range", 1,
      "The relevant input and output ranges are stated in meaningful units: the angular range of the sensor (270 degrees in the reference, with number of magnets and transitions), the range of the reference, and the output voltage range of the Hall sensors. If the behaviour is only valid in a certain range, this is mentioned.",
      ["range missing or only in raw counts",
       "angular range of the wheel and of the potentiometer mixed up",
       "range of one transition (unambiguous angle) not distinguished from the total range (needs counting)",
       "voltage range of the Hall sensors (used part of 0-5 V) not stated"],
      ["total angular range in degrees, with number of magnets and transitions",
       "range per transition (67.5 mechanical degrees for 9 magnets) mentioned",
       "output swing of the Hall sensors in V and in counts",
       "reference range (252 degrees electrical) compared with the wheel range (270 degrees)",
       "limit of the tracking mentioned (count lost when turned too fast or after a power cycle)"]),
    C("co_nonlin", "conclusion - non-linearities", 1,
      "Non-linearities and systematic errors in the behaviour of the sensor are clearly addressed, preferably with some quantification: the bumps between magnet transitions, the effect of the 2.5 V offset, amplitude mismatch and phase error, the edges of the range.",
      ["only 'it is not perfect', no numbers",
       "bumps seen but no explanation (offset, amplitude, phase, field shape) given",
       "edge errors attributed to the sensor without checking the range of the reference",
       "no comparison with an expectation (theory or datasheet)"],
      ["error pattern per magnet transition quantified (peak-to-peak in degrees, period 67.5 degrees)",
       "cause identified from the Lissajous plot (offset, unequal amplitude, phase error)",
       "edge effect explained by the reference (252 versus 270 degrees)",
       "compared with the datasheet (sensitivity tolerance, quiescent output error)"]),
    C("co_improve", "conclusion - improvements", 1,
      "The bottleneck(s) in the setup are mentioned and, where asked, options for improvement are given. The assignment asks for critical feedback on the process (systematic errors). Candidates: calibrating offset, amplitude and phase of each sensor, a look-up table or ellipse correction, more gain to use more of the ADC range, a smaller air gap or stronger field, a better reference (higher resolution, averaging).",
      ["no bottleneck named",
       "generic suggestions not linked to the results ('use a better sensor')",
       "systematic errors not discussed",
       "the limited resolution of the reference as a bottleneck not mentioned"],
      ["bottleneck identified from the data (used ADC range, bumps per transition, edge error, resolution of the potentiometer)",
       "concrete improvement (min / max calibration, ellipse correction, look-up table, amplifier or smaller gap)",
       "systematic errors named (offset, amplitude mismatch, phase, alignment, temperature)"]),
]))

# ───────────────────────────── 6. FORMAT · 3 pt ─────────────────────────────
S.append(("format", "format & structure", "6. FORMAT & STRUCTURE  ·  3 pt  (2+1)", [
    C("fo_template", "format - template", 2,
      "The template has been followed and used correctly: font, layout, figure numbering, references. No major blank sections or badly copy-pasted resources. No huge white spaces in blocks of code.",
      ["template sections missing or restructured",
       "template instruction text or specimen figures left in",
       "figure numbers inconsistent or duplicated",
       "figures without captions or not referenced in the text",
       "blank sections",
       "large white space in code blocks"],
      ["all template sections completed",
       "figures numbered consistently and referenced in the text",
       "compact, readable code blocks",
       "consistent fonts and layout"]),
    C("fo_references", "format - references", 1,
      "Where images, blocks of code or other resources were obtained elsewhere, they are clearly referenced.",
      ["datasheets not referenced (Hall sensor, magnet, potentiometer)",
       "wiki figures (schematic, shield drawing, wheel figure) used without source",
       "field simulation screenshot used without naming the calculator",
       "code adapted from wiki or reader without attribution"],
      ["datasheets referenced (Hall sensor, magnet, potentiometer)",
       "field calculator and wiki figures credited",
       "origin of adapted code stated"]),
]))

# ───────────────────────────── emit ─────────────────────────────
BAD = ['"', '`', '\\', '${']


def q(s):
    for b in BAD:
        assert b not in s, f"forbidden sequence {b!r} in: {s}"
    return '"' + s + '"'


def banner(text):
    bar = "═" * 64
    return f"  # {bar}\n  # {text}\n  # {bar}\n"


total = sum(c["pts"] for _, _, _, cs in S for c in cs)
assert total == 30, total

out = []
out.append(f"""# ══════════════════════════════════════════════════════════════════
#  RUBRIC DEFINITION - Sensors for Creative Technology
#  Assignment 6: Magnetic Sensing - Hall-effect rotary position sensor
#  (two linear Hall sensors + magnet wheel, potentiometer as reference)
#  ──────────────────────────────────────────────────────────────────
#  Total points: {total}
#  EU grade: 1 + 9 x (earned / {total})
#
#  1. Introduction         3 pt  (1+1+1)
#  2. Analysis             7 pt  (1+1+1+2+2)
#  3. Method & setup       6 pt  (1+2+1+1+1)
#  4. Results              5 pt  (1+1+1+1+1)
#  5. Conclusion           6 pt  (1+1+1+1+1+1)
#  6. Format & structure   3 pt  (2+1)
#
#  Same architecture as the Assignment 3 rubric: every criterion = one
#  slider (the points) + one observation checklist (points_per_positive: 0,
#  so it only generates feedback text and never changes the score).
#  Use the notes under the checklist for the Canvas 'Comment' field.
# ══════════════════════════════════════════════════════════════════

title: "Sensors - Hall-effect rotation sensor (Assignment 6)"
course: "SCT-A6"
grading: true
grade_decimals: 1

sections:
""")

for sid, stitle, sbanner, crits in S:
    out.append("\n" + banner(sbanner))
    out.append(f"  - id: {sid}\n    title: {q(stitle)}\n    fields:\n")
    for c in crits:
        lab = f"{c['label']} ({c['pts']} pt)"
        out.append(f"""
      - id: {c['id']}
        label: {q(lab)}
        type: slider
        min: 0
        max: {c['pts']}
        step: 1
        points: {c['pts']}
        description: {q(c['desc'])}

      - id: {c['id']}_obs
        label: {q('observations')}
        type: checklist
        points_per_positive: 0
        negative:
""")
        for n in c["neg"]:
            out.append(f"          - {q(n)}\n")
        out.append("        positive:\n")
        for p in c["pos"]:
            out.append(f"          - {q(p)}\n")

out.append("\n" + banner("7. OVERALL FEEDBACK  ·  no points"))
out.append("""  - id: overall
    title: "overall feedback"
    fields:

      - id: overall_note
        label: "overall feedback for the student"
        type: textarea
        placeholder: "Summary: strongest part, most important thing to improve..."
""")

text = "".join(out)
open(sys.argv[1] if len(sys.argv) > 1 else "rubric-sensors-hall.yaml", "w", encoding="utf-8").write(text)
print("written; total points", total, "; criteria", sum(len(cs) for *_, cs in S))
