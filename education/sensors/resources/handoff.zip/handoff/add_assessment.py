#!/usr/bin/env python3
"""Append one graded pair/student to the rubric session JSON.

usage:  python3 add_assessment.py SESSION.json GRADES.json [--dry-run]

GRADES.json:
{
  "students": [ {"name": "Anna Jansen - s1234567", "student": "Anna Jansen (s1234567)"},
                {"name": "Bram de Vries - s7654321", "student": "Bram de Vries (s7654321)"} ],
  "project": "Assignment 3 - Resistive Sensing (pair)",
  "scores": { "<criterion id>": {"score": 1, "neg": [0, 2], "pos": [1], "neg_note": "...", "pos_note": "..."}, ... },
  "overall": "overall feedback text"
}
Every criterion id of the rubric must be present (see criteria-cheatsheet.md for ids, points and checklist indices).
Strings must not contain double quotes, backticks, backslashes or the sequence dollar-brace.
A backup SESSION.json.bak is written before the session is changed.
"""
import json, sys, shutil
import yaml

BAD = ['"', '`', '\\', '${']

def check(s):
    for b in BAD:
        assert b not in s, f'forbidden sequence {b!r} in: {s[:60]}'

def main(session_path, grades_path, dry=False):
    data = json.load(open(session_path, encoding='utf-8'))
    g = json.load(open(grades_path, encoding='utf-8'))
    rub = yaml.safe_load(data['yaml'])
    fields = {f['id']: f for s in rub['sections'] for f in s['fields']}
    sliders = {k: f for k, f in fields.items() if f['type'] == 'slider'}
    missing = set(sliders) - set(g['scores']); extra = set(g['scores']) - set(sliders)
    assert not missing, f'missing criteria: {sorted(missing)}'
    assert not extra, f'unknown criteria: {sorted(extra)}'
    values, total = {}, 0
    for cid, e in g['scores'].items():
        sc = e['score']; assert isinstance(sc, int) and 0 <= sc <= sliders[cid]['points'], (cid, sc)
        values[cid] = sc; total += sc
        obs = fields[cid + '_obs']
        for i in e.get('neg', []):
            assert 0 <= i < len(obs['negative']), (cid, 'neg', i); values[f'{cid}_obs__neg__{i}'] = True
        for i in e.get('pos', []):
            assert 0 <= i < len(obs['positive']), (cid, 'pos', i); values[f'{cid}_obs__pos__{i}'] = True
        for key, suffix in (('neg_note', '__neg_note'), ('pos_note', '__pos_note')):
            if e.get(key):
                check(e[key]); values[f'{cid}_obs{suffix}'] = e[key]
    check(g.get('overall', '')); values['overall_note'] = g.get('overall', '')
    max_pts = sum(f['points'] for f in sliders.values())
    grade = round(1 + 9 * total / max_pts, 1)
    print(f'{total}/{max_pts} -> grade {grade}')
    if dry:
        return
    shutil.copy(session_path, session_path + '.bak')
    aid = data['aid']
    for st in g['students']:
        aid += 1
        data['assessments'].append({'id': f'a{aid}', 'name': st['name'],
                                    'meta': {'student': st['student'], 'project': g.get('project', ''), 'assessor': ''},
                                    'values': json.loads(json.dumps(values))})
    data['aid'] = aid
    json.dump(data, open(session_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('added', [s['name'] for s in g['students']], '- session now has', len(data['assessments']), 'assessments')

if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    main(args[0], args[1], dry='--dry-run' in sys.argv)
