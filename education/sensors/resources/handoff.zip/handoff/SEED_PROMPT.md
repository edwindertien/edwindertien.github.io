# Seed prompt for a new conversation (Assignment 6)

Upload first: `README.md`, `rubric-sensors-hall.yaml`, `rubric-sensors-a6.html`, `rubric-session-sensors-a6.json`, `add_assessment.py`, `criteria-cheatsheet.md`, `grading-matrix.md`, `grades/reference_example.json` (or the zip `assignment6-bundle.zip`). Then paste:

---
I am grading student reports for the course Sensors for Creative Technology, Assignment 6 (Hall-effect rotation sensor: two linear Hall sensors and a magnet wheel, potentiometer as reference). Read README.md first: it describes the rubric, the online grading tool, the session JSON, the grading conventions and the verified reference values.

For each student report (pdf or docx) I upload:
1. Read it and render the pages to look at the figures (convert a docx to pdf first). Recompute the key numbers yourself (swing in counts, resolution, angle per transition, whether the formulas in the text match the code) before judging.
2. Grade it with the 26 criteria using the conventions and the strictness in README.md and grading-matrix.md. Be honest about errors in the report and flag the 2-4 borderline calls.
3. Write a grade file and add the pair to the session JSON with add_assessment.py (same scores for both students of a pair, one assessment each). Do not change the rubric or earlier assessments.
4. Reply with: points and grade, a short table by section, strengths, technical findings, borderline calls, and the updated JSON file.

Start by confirming you have read README.md and by telling me which decision about the reference example (20/30 or 23/30) is recorded there. Then wait for the first report.
---
