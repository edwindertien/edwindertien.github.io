// Headless check of the grading tool: node test_tool.js TOOL.html SESSION.json
// setup once:  npm install jsdom js-yaml   (run in this folder)
const fs = require('fs'); const { JSDOM } = require('jsdom');
const [htmlPath, sessionPath] = process.argv.slice(2);
const yamlLib = fs.readFileSync('node_modules/js-yaml/dist/browser/js-yaml.umd.min.js', 'utf8');
let html = fs.readFileSync(htmlPath, 'utf8');
html = html.replace(/<script src="https:\/\/cdnjs[^>]*js-yaml[^>]*><\/script>/, () => '<script>' + yamlLib + '</script>');
const session = fs.readFileSync(sessionPath, 'utf8');
const key = (html.match(/localStorage\.getItem\('([^']+)'\)/) || [])[1];
const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'http://localhost/', pretendToBeVisual: true,
  beforeParse(w) { w.localStorage.setItem(key, session); w.fetch = () => Promise.reject(new Error('offline')); } });
setTimeout(() => {
  const w = dom.window;
  const names = JSON.parse(w.eval('JSON.stringify(assessments.map(a=>a.name))'));
  console.log('rubric:', w.eval('rubric.title'), '| sliders in form:', w.document.querySelectorAll('input[type=range]').length);
  for (const n of names) {
    w.eval(`currentId = assessments.find(a=>a.name===${JSON.stringify(n)}).id; renderAll();`);
    const p = JSON.parse(w.eval('JSON.stringify(computePoints())'));
    console.log(n.padEnd(48), 'points', p.earned + '/' + p.max, 'grade', (1 + 9 * p.earned / p.max).toFixed(1));
  }
}, 800);
