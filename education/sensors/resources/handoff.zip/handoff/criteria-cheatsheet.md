# Criteria cheatsheet - Sensors A6 (Hall-effect rotation sensor)

Use the indices below (0-based) in the grade files: neg / pos list the ticked observations. Scores are integers; grade = 1 + 9 x points / 30.

## introduction (3 pt)

### `intro_type` - introduction - sensor type (1 pt)
*Is the correct sensor type mentioned? (Two linear, ratiometric Hall-effect sensors (A1302 or similar) read out with a wheel of alternating magnets, and a potentiometer as reference.)*

Negative (to improve):
- [0] sensor type missing or vague (only 'an angle sensor')
- [1] only the Hall sensors, or only the potentiometer, named
- [2] wrong sensor type (e.g. optical encoder, or a Hall switch / latch instead of a linear Hall sensor)

Positive (well done):
- [0] linear (ratiometric) Hall-effect sensor named, together with the magnet wheel
- [1] potentiometer named as the reference

### `intro_principle` - introduction - physical principle (1 pt)
*Is the physical measurement principle mentioned?*

Negative (to improve):
- [0] no physical principle mentioned
- [1] principle given for only one of the two sensors (Hall or potentiometer)
- [2] describes the electronics or the process instead of the physics

Positive (well done):
- [0] Hall effect: a magnetic field gives an output voltage proportional to the flux density
- [1] two sensors with a 90 degree phase difference give a sine / cosine pair from which the angle follows
- [2] potentiometer: wiper voltage proportional to the angle

### `intro_goal` - introduction - measurement goal (1 pt)
*Is the goal clearly stated, without irrelevant (process-related) information?*

Negative (to improve):
- [0] goal missing or unclear
- [1] goal buried in a description of what was done or which hardware was handed out
- [2] goal is only 'to do the assignment'

Positive (well done):
- [0] goal stated in one or two sentences (implement and characterise the Hall-effect angle sensor with the potentiometer as reference)
- [1] properties to be determined are named (angular range, resolution, precision, accuracy)

## analysis (7 pt)

### `an_measurand` - analysis - measurand (1 pt)
*It is clearly described what is measured: which physical quantity and in which units. Reference: the rotation angle of the wheel (mechanical angle, in degrees) over the total range (270 degrees for the 9-magnet wheel). One magnet transition is 360 electrical degrees, which is two magnet pitches (67.5 mechanical degrees), so electrical and mechanical angle must not be mixed up.*

Negative (to improve):
- [0] measurand not named
- [1] mechanical and electrical angle mixed up (a transition is 360 electrical degrees, not 360 mechanical degrees)
- [2] only raw ADC counts or volts, no angle unit
- [3] degrees and radians mixed, or units inconsistent between text and graphs

Positive (well done):
- [0] measurand named explicitly (rotation angle of the wheel)
- [1] unit stated (degrees) with the relation between electrical and mechanical angle (360 electrical degrees = 2 magnet pitches = 67.5 degrees for 9 magnets over 270 degrees)
- [2] same units used throughout text and graphs

### `an_principle` - analysis - physical principle (1 pt)
*The physical principle used for the sensor is described concisely and correctly: Hall effect with magnets of alternating polarity, a linear ratiometric output around half the supply voltage, and why two sensors with a phase offset give a sine / cosine pair. Note: part of this text is pre-filled in the template, so look for the student's own explanation.*

Negative (to improve):
- [0] only the pre-filled template text, no own explanation
- [1] alternating polarity of the magnets not mentioned, so the period per transition is unexplained
- [2] Hall sensor described wrongly (e.g. output proportional to the magnet position, or a switching output instead of a linear one)
- [3] phase difference not explained (sensor distance versus magnet distance, see the figure with D_sensor and D_magnet)
- [4] not concise (copied datasheet text)

Positive (well done):
- [0] output voltage proportional to the field through the sensor, quiescent output at half the supply, ratiometric
- [1] magnets alternate N / S, so one transition (360 electrical degrees) spans two magnet pitches
- [2] sensor spacing equals one transition plus 90 degrees, which gives the sine / cosine pair
- [3] concise and correct

### `an_reference` - analysis - the reference (1 pt)
*The reference used to characterise the sensor is discussed, including its operating principle and its limits. Reference values: rotary potentiometer 10 kOhm, wiper voltage proportional to the angle; effective (electrical) angle about 252 degrees for the full output swing (the mechanical stop of the RK09K family is about 280 degrees); read with the 10-bit ADC, which is 0.25 degrees per count.*

Negative (to improve):
- [0] reference mentioned but operating principle not explained (resistive divider with a wiper)
- [1] potentiometer specifications missing or wrong (electrical angle, resistance, taper)
- [2] no discussion of the limits of the reference (electrical versus mechanical angle, linearity tolerance, ADC resolution)
- [3] no discussion of how the potentiometer angle is aligned with the wheel angle (zero offset, angle range)

Positive (well done):
- [0] wiper of the 10 kOhm potentiometer as a voltage divider explained
- [1] specifications quoted correctly with source (effective electrical angle, linear taper)
- [2] reference limitations mentioned (electrical angle smaller than the wheel range, 0.25 degrees per ADC count, linearity)
- [3] alignment of the two angle scales discussed

### `an_equations` - analysis - relevant equations (2 pt)
*The equations from physical quantity, to electrical signal (voltage), to value in degrees (software), for both the sensor and the reference. Reference values: about 480 G at the sensor (field calculator, N45 magnet 4 x 1.5 mm) x 1.3 mV/G = about 0.62 V swing around 2.5 V = about 245 ADC counts peak-to-peak (a quarter of the ADC range); x = (A4 - mid) / amplitude, y = (A5 - mid) / amplitude; theta_el = atan2(y, x); unwrapping by adding or subtracting 360 at every jump; theta = summed electrical angle x 270 / 1440 for 9 magnets (4 transitions); reference angle = 252 x ADC / 1023.*

Negative (to improve):
- [0] no chain from field to voltage to ADC count to angle
- [1] equations only for one of the two sensors
- [2] arctan(y / x) used where atan2 is needed (quadrant lost), or the two signals swapped or not offset-corrected
- [3] transition counting (unwrapping) not given
- [4] scaling from summed electrical angle to mechanical angle missing or inverted (multiply versus divide)
- [5] expected voltage swing from sensitivity and field calculator not given
- [6] template placeholders left empty ([n], [deg], [mV/gauss])

Positive (well done):
- [0] sensitivity and field combined to the expected swing in mV and in ADC counts
- [1] angle within one transition from atan2 of the two offset-corrected signals
- [2] unwrapping rule and scaling to mechanical degrees correct and consistent with the code
- [3] reference angle equation with the datasheet value of the potentiometer
- [4] all values with units

### `an_conditioning` - analysis - conditioning (2 pt)
*The circuits used for conditioning the sensor signals are described: supply and output of the Hall sensors, the potentiometer divider, the ADC inputs (A4, A5, A0). The expected use of the ADC range is discussed (the signals only occupy a small part of 0-5 V) and the offset and amplitude correction (centre at 2.5 V, normalisation) is explained. The used components are shown in the schematic.*

Negative (to improve):
- [0] schematic missing, or template specimen left in
- [1] components or pin numbers (A4, A5, A0) not labelled
- [2] only one of the two signal paths shown (Hall sensors or potentiometer)
- [3] fraction of the ADC range that is used not estimated
- [4] offset (2.5 V centre) and amplitude not discussed, a fixed value of 512 assumed without comment
- [5] figure not referenced in the text

Positive (well done):
- [0] schematic shows both Hall sensors on A4 and A5 and the potentiometer on A0
- [1] component values and designators match the text
- [2] expected swing compared with the ADC range (about 245 of 1023 counts)
- [3] ratiometric output read by a ratiometric ADC (supply variations cancel), and tolerance of quiescent output and sensitivity mentioned
- [4] figure referenced where discussed

## method & setup (6 pt)

### `me_setup` - method - setup (1 pt)
*The setup is described: physical aspects (the wheel with its number of magnets and their spacing, the distance between magnets and sensors, how the wheel is turned, where the potentiometer sits), location of the used components on the shield, and the setting of the experiment (room, temperature, at a desk).*

Negative (to improve):
- [0] no physical description (wheel, magnets, air gap, how it is rotated)
- [1] shield drawing missing, generic, or used parts not marked
- [2] number of magnets, spacing or air gap not stated
- [3] experiment conditions (room, temperature, desk) not mentioned
- [4] no photo or sketch of the wheel and the magnet placement

Positive (well done):
- [0] annotated shield drawing marking the Hall sensors and the potentiometer
- [1] wheel drawing or photo with the number of magnets, spacing (33.75 degrees for 9 magnets over 270 degrees) and air gap
- [2] conditions stated (room, approximate temperature, table)
- [3] how the wheel was turned (by hand, slowly) described

### `me_code` - method - code (2 pt)
*The code used for the experiment is described and given. Concise, cleaned-up and minimal; copy-pasting from the reader is not the way to go. The code outputs the computed angle and the reference angle.*

Negative (to improve):
- [0] code copied from the reader or wiki without cleaning
- [1] long listing with unused parts or no comments
- [2] constants or formulas in the code do not match the text (offset, scaling 270/1440, atan2 argument order)
- [3] code for the angle or for the reference conversion missing
- [4] no unwrapping (transition counting) in the code
- [5] listing formatted poorly (large white space, unreadable)

Positive (well done):
- [0] short listing covering both conversions (Hall angle and potentiometer angle per line)
- [1] unwrapping and scaling visible and matching the text
- [2] constants (centre, amplitude, scale) traceable to the data
- [3] code explained in the text (what it does, sample rate)

### `me_reference` - method - reference (1 pt)
*The reference signal, reference measurement or calibration source is described.*

Negative (to improve):
- [0] no description of how the potentiometer angle is obtained (range, offset)
- [1] zero position of wheel and potentiometer not aligned, or the alignment not described
- [2] potentiometer range taken from the datasheet without checking it against the wheel range
- [3] 'calibrated' claimed without any data

Positive (well done):
- [0] potentiometer conversion with the effective angle from the datasheet
- [1] alignment (offset and scale) of the reference and the sensor angle determined from the data
- [2] accuracy or resolution of the reference mentioned (0.25 degrees per count, linearity)

### `me_samples` - method - samples (1 pt)
*The number of samples, measurements or series taken is stated.*

Negative (to improve):
- [0] number of swings or samples not stated
- [1] only a single swing
- [2] sampling interval / rate not mentioned
- [3] no static points or sorted data for the precision

Positive (well done):
- [0] number of swings and direction (up and down) stated
- [1] sample rate stated
- [2] enough swings to see repeatability (3 or more)
- [3] number of samples behind the precision value stated

### `me_procedure` - method - procedure (1 pt)
*The steps taken, and in which order, are described.*

Negative (to improve):
- [0] steps not in order or not reproducible
- [1] rotation speed or direction not described
- [2] unclear how the starting position and the transition count were initialised
- [3] end stops of the potentiometer or the wheel range not mentioned

Positive (well done):
- [0] ordered steps from raw signals to calibrated angle
- [1] slow, repeated swings over the full range, in both directions
- [2] starting position and initial segment defined
- [3] precision measured at fixed angles (holds) or by sorting the data

## results (5 pt)

### `re_time` - results - time series (1 pt)
*A clear graph showing the experimental procedure: the raw values of the two Hall sensors and the potentiometer in time over a number of swings, corresponding to the outlined procedure. The raw values show how much of the ADC range is used.*

Negative (to improve):
- [0] no time series of the raw values shown
- [1] swings not recognisable
- [2] time axis in sample number only, or not in seconds
- [3] raw counts and degrees on one unlabelled axis
- [4] the two Hall signals not distinguishable

Positive (well done):
- [0] raw A4, A5 and potentiometer in one graph, clear swings
- [1] time axis in seconds
- [2] used part of the ADC range visible (about 400-600 counts)
- [3] corresponds to the described procedure

### `re_calibration` - results - calibration graph (1 pt)
*A clear graph showing sensor data and reference data. A time series can be added, but the important one is the x-y graph of the calculated angle versus the potentiometer angle.*

Negative (to improve):
- [0] no x-y plot, only time series
- [1] axes swapped (reference belongs on x)
- [2] no ideal line (y = x) to judge the deviation
- [3] unlabelled axes or units
- [4] offset between the two angle scales not corrected

Positive (well done):
- [0] x-y plot: calculated angle versus reference angle, in degrees
- [1] ideal line drawn
- [2] several swings visible
- [3] calculated angle and reference also shown in one time series

### `re_error` - results - error plot (1 pt)
*A clear graph showing the error (difference between reference and measured value). The reference angle range on the x-axis is better than the time series.*

Negative (to improve):
- [0] no error plot
- [1] error plotted against time instead of against the reference angle
- [2] error definition or sign not stated
- [3] edges of the range (where the reference saturates) not commented

Positive (well done):
- [0] error versus reference angle, in degrees
- [1] valid range indicated, or the edges explained
- [2] sign convention stated
- [3] periodic pattern with the magnet pitch visible or discussed

### `re_nonlinear` - results - non-ideal details (1 pt)
*Graphs showing relevant details of non-ideal behaviour: the x-y (Lissajous) plot of the two Hall signals (a circle when offsets, amplitudes and the 90 degree phase are right), the error within one magnet transition, or a close-up showing the resolution steps. (Hysteresis is not asked in this assignment.)*

Negative (to improve):
- [0] non-ideal behaviour claimed (bumps, edge errors) but not shown
- [1] no x-y plot of the two Hall signals
- [2] no close-up of one or two transitions
- [3] bumps visible in the angle but not analysed

Positive (well done):
- [0] Lissajous plot of A4 against A5 showing offset, ellipse or distortion
- [1] close-up of a few transitions with the error pattern
- [2] close-up of the angle steps at slow rotation (resolution)

### `re_graphing` - results - graphing quality (1 pt)
*The graphs show a relevant number of samples, have good scaling, and relevant (SI) units on the axes (degrees, seconds, counts or volts).*

Negative (to improve):
- [0] axis titles or units missing (default chart titles)
- [1] raw counts and angles mixed on one axis
- [2] poor scaling, or too few samples
- [3] units not consistent with the text (degrees versus radians, electrical versus mechanical)

Positive (well done):
- [0] all axes labelled with units
- [1] sensible scaling and enough samples
- [2] units consistent with the text

## conclusion (6 pt)

### `co_accuracy` - conclusion - accuracy (1 pt)
*A meaningful and quantified notion of accuracy, linked to the angular range of the sensor. The accuracy of the reference is discussed too. The mean and standard deviation of the error tell only part of the story: look for the worst-case error, and the error in the middle of the range versus the edges.*

Negative (to improve):
- [0] accuracy given only as the mean error (close to zero by symmetry)
- [1] no link to the range (no percentage of the 270 degrees)
- [2] accuracy of the reference (linearity, ADC step, electrical angle) not discussed
- [3] edge errors (outside the valid reference range) included without comment

Positive (well done):
- [0] worst-case or RMS error in degrees and as percentage of the range
- [1] accuracy of the reference discussed (potentiometer linearity, 0.25 degrees per count)
- [2] range over which the number holds is stated
- [3] error without the edge region also given

### `co_resolution` - conclusion - resolution (1 pt)
*A meaningful, quantified notion of resolution, for both the reference and the sensor signal. Pay attention to the voltage range that the Hall sensors actually use. Reference: potentiometer 252 / 1023 = 0.25 degrees per count; Hall signals: a swing of about 245 counts (a quarter of the ADC range); a single-signal estimate gives 270 / 960 = 0.28 degrees; with two signals and atan2 the electrical resolution is about 1 / A radians (A = amplitude in counts, about 120), which is about 0.1 mechanical degrees.*

Negative (to improve):
- [0] resolution only as ADC bits or counts, not translated to degrees
- [1] voltage range actually used (about 0.6 V around 2.5 V) not taken into account: 10 bit assumed over the full range
- [2] no value for the Hall angle, or none for the reference
- [3] resolution of the reference not compared with that of the sensor
- [4] single-signal estimate used without discussing the effect of combining two signals

Positive (well done):
- [0] reference resolution in degrees per count (about 0.25 degrees)
- [1] used ADC range translated into degrees per count for the Hall signals
- [2] effective resolution with atan2 derived or measured from the data (smallest step at slow rotation)
- [3] limit of the reference as measurement instrument mentioned

### `co_precision` - conclusion - precision (1 pt)
*Precision can be calculated from multiple measurements of the same thing (the same angle), giving a (standard) deviation. The standard deviation of the error is related, but repeated readings at fixed angles, or the sorted data at a number of angles, is better.*

Negative (to improve):
- [0] precision confused with accuracy (standard deviation of the error over the whole range called precision)
- [1] no repeated measurement at the same angle
- [2] standard deviation of the error given without noting its limitation (it contains systematic errors per transition)

Positive (well done):
- [0] standard deviation of repeated readings at fixed angles (static holds) or of sorted data per angle bin
- [1] noise in ADC counts translated into degrees
- [2] number of samples behind the value stated

### `co_range` - conclusion - range (1 pt)
*The relevant input and output ranges are stated in meaningful units: the angular range of the sensor (270 degrees in the reference, with number of magnets and transitions), the range of the reference, and the output voltage range of the Hall sensors. If the behaviour is only valid in a certain range, this is mentioned.*

Negative (to improve):
- [0] range missing or only in raw counts
- [1] angular range of the wheel and of the potentiometer mixed up
- [2] range of one transition (unambiguous angle) not distinguished from the total range (needs counting)
- [3] voltage range of the Hall sensors (used part of 0-5 V) not stated

Positive (well done):
- [0] total angular range in degrees, with number of magnets and transitions
- [1] range per transition (67.5 mechanical degrees for 9 magnets) mentioned
- [2] output swing of the Hall sensors in V and in counts
- [3] reference range (252 degrees electrical) compared with the wheel range (270 degrees)
- [4] limit of the tracking mentioned (count lost when turned too fast or after a power cycle)

### `co_nonlin` - conclusion - non-linearities (1 pt)
*Non-linearities and systematic errors in the behaviour of the sensor are clearly addressed, preferably with some quantification: the bumps between magnet transitions, the effect of the 2.5 V offset, amplitude mismatch and phase error, the edges of the range.*

Negative (to improve):
- [0] only 'it is not perfect', no numbers
- [1] bumps seen but no explanation (offset, amplitude, phase, field shape) given
- [2] edge errors attributed to the sensor without checking the range of the reference
- [3] no comparison with an expectation (theory or datasheet)

Positive (well done):
- [0] error pattern per magnet transition quantified (peak-to-peak in degrees, period 67.5 degrees)
- [1] cause identified from the Lissajous plot (offset, unequal amplitude, phase error)
- [2] edge effect explained by the reference (252 versus 270 degrees)
- [3] compared with the datasheet (sensitivity tolerance, quiescent output error)

### `co_improve` - conclusion - improvements (1 pt)
*The bottleneck(s) in the setup are mentioned and, where asked, options for improvement are given. The assignment asks for critical feedback on the process (systematic errors). Candidates: calibrating offset, amplitude and phase of each sensor, a look-up table or ellipse correction, more gain to use more of the ADC range, a smaller air gap or stronger field, a better reference (higher resolution, averaging).*

Negative (to improve):
- [0] no bottleneck named
- [1] generic suggestions not linked to the results ('use a better sensor')
- [2] systematic errors not discussed
- [3] the limited resolution of the reference as a bottleneck not mentioned

Positive (well done):
- [0] bottleneck identified from the data (used ADC range, bumps per transition, edge error, resolution of the potentiometer)
- [1] concrete improvement (min / max calibration, ellipse correction, look-up table, amplifier or smaller gap)
- [2] systematic errors named (offset, amplitude mismatch, phase, alignment, temperature)

## format & structure (3 pt)

### `fo_template` - format - template (2 pt)
*The template has been followed and used correctly: font, layout, figure numbering, references. No major blank sections or badly copy-pasted resources. No huge white spaces in blocks of code.*

Negative (to improve):
- [0] template sections missing or restructured
- [1] template instruction text or specimen figures left in
- [2] figure numbers inconsistent or duplicated
- [3] figures without captions or not referenced in the text
- [4] blank sections
- [5] large white space in code blocks

Positive (well done):
- [0] all template sections completed
- [1] figures numbered consistently and referenced in the text
- [2] compact, readable code blocks
- [3] consistent fonts and layout

### `fo_references` - format - references (1 pt)
*Where images, blocks of code or other resources were obtained elsewhere, they are clearly referenced.*

Negative (to improve):
- [0] datasheets not referenced (Hall sensor, magnet, potentiometer)
- [1] wiki figures (schematic, shield drawing, wheel figure) used without source
- [2] field simulation screenshot used without naming the calculator
- [3] code adapted from wiki or reader without attribution

Positive (well done):
- [0] datasheets referenced (Hall sensor, magnet, potentiometer)
- [1] field calculator and wiki figures credited
- [2] origin of adapted code stated
